const os = require('os');

console.log('Windows', os.platform());
console.log('Архитектура процессора', os.arch());

console.log('info', os.cpus());
console.log('cach', os.freemem());
console.log('all cach', os.totalmem());
console.log('all cach', os.homedir());
console.log('up', os.uptime());

