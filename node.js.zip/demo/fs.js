const fs = require('fs');
const path = require('path');

// fs.mkdir(path.join(__dirname, 'test'), (err) =>{
//     if(err){
//         throw err
//     }
//     console.log('Folder is created');
// })

const filePath = path.join(__dirname, 'test', 'test.txt');

// fs.writeFile(filePath, 'Hello Node', err => {
//     if (err){
//         throw err
//     }
//     console.log('file is creaited ')
// })

// fs.appendFile(filePath, '\nHello again', err => {
//     if (err){
//         throw err
//     }
//     console.log('file is creaited ')
// })

fs.readFile(filePath,'utf-8', (err, content) =>{
    if(err){
        throw err
    }
    console.log(content);
})