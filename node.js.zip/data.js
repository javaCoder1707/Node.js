const text = ' Hello node.js from data.js  ';

module.exports = text ;