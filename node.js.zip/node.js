// const chalk = require('chalk')
// const text = require('./data')
// console.log(chalk.blue(text));

// const http = require('http');

//  const server = http.createServer(requestListener:(req, res) =>{
// res.end(chunk:'hello')
// })
// server.listen(port,3000, listeningListener, ()=>{
//     console.log('server...');
    
// } )